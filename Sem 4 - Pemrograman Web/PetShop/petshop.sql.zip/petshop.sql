--
-- Database: `petshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_pelanggan`
--

CREATE TABLE `data_pelanggan` (
  `id` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(12) NOT NULL,
  `Alamat` text NOT NULL,
  `kodepos` int(10) NOT NULL,
  `tlp` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_pelanggan`
--

INSERT INTO `data_pelanggan` (`id`, `Nama`, `Email`, `Password`, `Alamat`, `kodepos`, `tlp`) VALUES
(0, 'Fery E', 'FerEka@gmail.com', '12345', 'Malang', 65153, '08123456789'),
(0, 'Fery', 'Fery@gmail.com', '123456', 'Surabaya', 65153, '0896331252'),
(0, 'Fery Eka', 'FeryE@gmail.com', '12345', 'Surabaya', 65153, '08123456789'),
(0, 'Luqman', 'Luqman@gmail.com', '12345', 'Madura', 65144, '0862318423');

-- --------------------------------------------------------

--
-- Table structure for table `data_toko`
--

CREATE TABLE `data_toko` (
  `ID_Barang` int(100) NOT NULL,
  `Nama_Barang` varchar(100) NOT NULL,
  `Kategori` varchar(50) NOT NULL,
  `Harga` varchar(12) NOT NULL,
  `Stok` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_toko`
--

INSERT INTO `data_toko` (`ID_Barang`, `Nama_Barang`, `Kategori`, `Harga`, `Stok`) VALUES
(1, 'Baju Hewan', 'Anjing', '20000', 10),
(2, 'Kalung', 'Anjing/Kucing', '5000', 20),
(3, 'Kandang', 'Kucing', '50000', 5),
(4, 'Tempat Makan', 'Kucing/Anjing', '56000', 10),
(5, 'Tempat Tidur', 'Kucing/Anjing', '60000', 25),
(6, 'Peralatan Kebersihan', 'Kucing', '45000', 10),
(101, 'Canibite 20kg', 'Anjing', '290000', 10),
(102, 'Pedigree 1.5kg', 'Anjing', '60000', 10),
(103, 'Felibite 20kg', 'Kucing', '415000', 10),
(104, 'Roy Canin 8.5gr', 'Kucing', '22000', 10),
(105, 'Whiskas 85gr', 'Kucing', '6000', 10),
(106, 'Bloodworms 20gr', 'Ikan', '105000', 10),
(201, 'Obat Antibiotik', 'Kucing', '30000', 10),
(202, 'Obat Flu', 'Kucing', '30000', 10),
(203, 'Obat Mata', 'Kucing', '30000', 10),
(204, 'Obat Diare', 'Kucing', '27000', 10),
(205, 'Obat Bulu', 'Kucing', '25000', 10),
(206, 'Antibakteri', 'Ikan', '90000', 10);

-- --------------------------------------------------------

--
-- Table structure for table `oderdetail`
--

CREATE TABLE `oderdetail` (
  `productid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `price` float NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `oderdetail`
--

INSERT INTO `oderdetail` (`productid`, `orderid`, `price`, `quantity`) VALUES
(1, 0, 2000, 2),
(1, 0, 2000, 2),
(1, 0, 2000, 1),
(1, 0, 2000, 3),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(1, 0, 2000, 1),
(101, 0, 290000, 1),
(1, 0, 20000, 1),
(1, 0, 20000, 2),
(205, 0, 25000, 2),
(3, 0, 50000, 1),
(102, 0, 60000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `datecreation` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_pelanggan`
--
ALTER TABLE `data_pelanggan`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `data_toko`
--
ALTER TABLE `data_toko`
  ADD PRIMARY KEY (`ID_Barang`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
